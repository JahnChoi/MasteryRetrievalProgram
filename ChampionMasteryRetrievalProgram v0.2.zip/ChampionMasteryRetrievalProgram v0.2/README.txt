2/17/17 v0.2
- Added feature for displaying ranks.